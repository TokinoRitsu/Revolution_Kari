
thank you for using the desert_ asset pack...part of the fantasy_ series' on itch.io!



stuff to know - tilesets

- each tile is 16 x 16 pixels...although some structures/objcets take up multiple tiles [e.g. fountain, big rock, etc]
- each tileset has a 1 tile [16 pixels] border...although some structures have details that are in the border-tile

stuff to know - animated tiles

- each animated tile has 4 frames
- bridge water animations are in a seperate tileset [desert_ [bridgeAnimatedTiles] to the static bridge tiles [desert_ [bridgeHorizontal]]



future updates/asset packs - 

- desertDungeon_ entrance
- more burried stuff

- swampSprites_ [version 1.0]
- dungeon_ [version 2.0]
- villageSprites_ [version 1.0] [a collection of villagers and merchants]
- fantasySprites_ [a collection of all of the sprite assets from the fantasy_ series']



...if you have any questions or requests you can contact me at analogstudios.inc@gmail.com





                                                             